<?php $this->renderpartial('_form', array('model' => $model, '_mode_' => 'insert', 'msg' => $msg,'project_id'=>$project_id)); ?>
